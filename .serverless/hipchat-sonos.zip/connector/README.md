# Sonos-HipChat
A hipchat bot for sonos players<br>
This app requires two libraries:<br>
https://github.com/SoCo/SoCo<br>
https://github.com/RidersDiscountCom/HypChat<br>

Both can be installed via pip (which itself can be downloaded here: https://pypi.python.org/pypi/pip)<br>
pip install hypchat<br>
pip install soco<br>

To use this with your Sonos system and hipchat you will need:<br>
-The IP Address of your Sonos Player<br>
-Your hipchat auth token (get it here: https://www.hipchat.com/account/api)<br>
-The name of a hipchat room for your bot to live in<br>

Once you have these things just add them to the config.txt file<br>

After that open a command prompt, navigate to the folder containing roomSonos.py and enter:<br>
python roomPython.py<br>
